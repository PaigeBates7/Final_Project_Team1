from django.shortcuts import render, get_object_or_404
from .models import CareerFields, Career, Skills
from .utils.queries import get_skills_by_field, get_skills_by_career

# Create your views here.

def home(request):
    return render(request, 'home.html')

def aboutUs(request):
    return render(request, 'aboutUs.html')

def dictionary(request):
    return render(request, 'dictionary.html')

def index(request):
    return render(request, 'index.html')

def profile(request):
    return render(request, 'profile.html')

def profileResult(request):
    return render(request, 'ProfileResult.html')

def programmingFields(request):
    return render(request, 'programmingFields.html')

def field_skills_view(request, field_id):
    career_field = get_object_or_404(CareerFields, careerfield_ID=field_id)
    skills = get_skills_by_field(field_id)
    return render(request, 'FieldSkills.html', {'career_field': career_field, 'skills': skills})    


def career_skills_view(request, career_ID):
    career = get_object_or_404(Career, career_ID=career_ID)
    skills = get_skills_by_career(career_ID)
    return render(request, 'CareerSkills.html', {'career': career, 'skills': skills})