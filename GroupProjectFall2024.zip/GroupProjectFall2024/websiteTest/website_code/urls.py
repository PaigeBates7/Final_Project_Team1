from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  
    path('aboutUs/', views.aboutUs, name='aboutUs'),  
    path('dictionary/', views.dictionary, name='dictionary'), 
    path('index/', views.index, name='index'),
    path('profile/', views.profile, name='profile'),
    path('profileResult/', views.profileResult, name='profileResult'),
    path('programmingFields/', views.programmingFields, name='programmingFields'),
    path('career/<int:career_ID>/skills/', views.career_skills_view, name='career_skills'),
]