from ..models import FieldSkills, Skills, CareerSkills

def get_skills_by_field(field_id):
    """
    Fetches skills associated with a specific career field.

    Args:
        field_id (int): The ID of the career field to query.

    Returns:
        QuerySet: A QuerySet of skill objects associated with the field.
    """
    field_skills = FieldSkills.objects.filter(careerfield_ID=field_id)
    skill_ids = field_skills.values_list('skill_ID', flat=True)
    skills = Skills.objects.filter(id__in=skill_ids)
    return skills



def get_skills_by_career(career_ID):
    """
    Fetches skills associated with a specific career.

    Args:
        career_id (int): The ID of the career to query.

    Returns:
        QuerySet: A QuerySet of skill objects associated with the career.
    """
    career_skills = CareerSkills.objects.filter(career_ID=career_ID)
    skill_ids = career_skills.values_list('skill_ID', flat=True)
    skills = Skills.objects.filter(skill_ID__in=skill_ids)
    return skills